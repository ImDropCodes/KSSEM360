package in.edu.kssem360.Admin;

import androidx.appcompat.app.AppCompatActivity;
import in.edu.kssem360.R;

import android.os.Bundle;

public class AdminEventUpdate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_event_update);
    }
}
